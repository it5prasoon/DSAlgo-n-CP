# Output

- ### Problem 2.1

       Write a program to check if the given input is an Alphabet.

  <img src="./Problem_2.1/2.1.png" alt="2.1" style="width:700px">

  ***

- ### Problem 2.2

      Write a program to check if the given input contains only Alphabets.

  <img src="./Problem_2.2/2.2.png" alt="2.2" style="width:700px">

  ***

- ### Problem 2.3

      Write a program to check if the given input is a Digit or an Alphabet.

   <img src="./Problem_2.3/2.3.png" alt="2.3" style="width:700px">

---

- ### Problem 2.4

      Write a program to check if the given input contains only Uppercase letters or Lowercase letters or Digits or Special
      characters or Mixed characters.

   <img src="./Problem_2.4/2.4.png" alt="2.4" style="width:700px">
