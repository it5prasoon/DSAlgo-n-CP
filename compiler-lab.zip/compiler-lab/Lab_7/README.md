# Output

- ### Problem 7.1

      Write a lex program to count the number of characters, whitespaces, tabs and lines in the Input file.

  <img src="./Problem_7.1/7.1.png" alt="7.1" style="width:700px">

---

- ### Problem 7.2

      Write a lex program to count the number of lexemes in the Input file.

   <img src="./Problem_7.2/7.2.png" alt="7.2" style="width:700px">
   
   ----
* ### Problem 7.3

      Write a lex program to take input from a file and remove multiple whitespace, tab and newline and write output in a separate file.
