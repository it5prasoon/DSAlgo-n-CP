# Output

- ### Problem 6.1

       Write a lex program to check whether the input Mobile Number is Valid or Not.

  <img src="./Problem_6.1/6.1.png" alt="6.1" style="width:700px">

---

- ### Problem 6.2

       Write a lex program to check whether the input string is a Valid Email address or not.

   <img src="./Problem_6.2/6.2.png" alt="6.2" style="width:700px">

---

- ### Problem 6.3

       Write a lex program to count the number of characters in the Input file.

   <img src="./Problem_6.3/6.3.png" alt="6.3" style="width:700px">
