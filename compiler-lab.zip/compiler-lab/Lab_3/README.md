# Output

- ### Problem 3.1

       Write a program to check if the given input is a consonant or a vowel.

  <img src="./Problem_3.1/3.1.png" alt="1.1" style="width:700px">

---

- ### Problem 3.2

      Write a program to count the total number of characters in the input.

   <img src="./Problem_3.2/3.2.png" alt="1.1" style="width:700px">

---

- ### Problem 3.3

      Write a program to count the vowel, consonant, digit and whitespace in the given input.

   <img src="./Problem_3.3/3.3.png" alt="1.1" style="width:700px">
