# Output

- ### Problem 5.1

      Write a lex program to count the total number of lexemes.

  <img src="./Problem_5.1/5.1.png" alt="5.1" style="width:700px">

---

- ### Problem 5.2

      Write a lex program to count the number of keywords, identifiers, operators, integers etc.

   <img src="./Problem_5.2/5.2.png" alt="5.2" style="width:700px">

---

- ### Problem 5.3

      Write a lex program to check URL is Valid or Not.

   <img src="./Problem_5.3/5.3.png" alt="5.3" style="width:700px">
