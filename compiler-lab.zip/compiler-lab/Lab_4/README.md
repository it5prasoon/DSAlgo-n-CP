# Output

- ### Problem 4.1

       Write a lex program to check whether the input string is a Valid Keyword in C or not.

  <img src="./Problem_4.1/4.1.png" alt="4.1" style="width:700px">

---

- ### Problem 4.2

      Write a lex program to check whether the input string is a Valid Indentifier in C or not.

   <img src="./Problem_4.2/4.2.png" alt="4.2" style="width:700px">

---

- ### Problem 4.3

      Write a lex program to check whether the input is a Valid Operator in C or not.

   <img src="./Problem_4.3/4.3.png" alt="4.3" style="width:700px">

---

- ### Problem 4.4

      Write a lex program to check whether the input is an Integer or a Floating-point number.

   <img src="./Problem_4.4/4.4.png" alt="4.4" style="width:700px">
