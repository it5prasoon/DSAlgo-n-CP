
  <p align="center">
  <img src="./IIITRanchiLogo.png" alt="InstituteLogo" width="200">
   </p>

   # Compiler Design Lab Record
   
   ## Introduction

| Name          | Nitish Kumar |
| ------------- | ------------- |
| Roll No.      | 2019UGCS023R  |
| Branch        | Computer Science and Engineering  |
| Subject       | Compiler Design Lab Record |
| Subject Code  | CS324 |
| Faculty       | Dr. Bhaskar Mondal  |

