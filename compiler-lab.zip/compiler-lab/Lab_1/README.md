# Output

- ### Problem 1.1

        Write a lex program to check if the given input is a Digit.

  <img src="./Problem_1.1/1.1.png" alt="1.1" style="width:700px">
